# object_detection
Aim -  Develop a system that can detect and classify objects in images or video streams.  Description- Create an object detection model capable of identifying and locating multiple  objects within an image or video.   Technologies- Python, TensorFlow or PyTorch, OpenCV
Run or Download : wget https://pjreddie.com/media/files/yolov3.weights
