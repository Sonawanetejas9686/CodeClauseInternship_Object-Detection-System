import cv2
import numpy as np
import time

def load_yolo():
    weights_path = "c:/Users/Tejas Sonawane/Downloads/object_detection-main/object_detection-main/yolov3.weights"
    config_path = "c:/Users/Tejas Sonawane/Downloads/object_detection-main/object_detection-main/yolov3.cfg"
    
    # Load the YOLO network
    net = cv2.dnn.readNet(weights_path, config_path)
    
    # Load the class names
    classes = []
    with open("c:/Users/Tejas Sonawane/Downloads/object_detection-main/object_detection-main/coco.names", "r") as f:
        classes = [line.strip() for line in f.readlines()]
    
    # Get the output layer names
    layer_names = net.getLayerNames()
    print(f"Layer names: {layer_names}")
    unconnected_out_layers = net.getUnconnectedOutLayers()
    print(f"Unconnected output layers: {unconnected_out_layers}")
    
    # Adjusting index extraction to handle possible differences
    output_layers = [layer_names[i - 1] for i in unconnected_out_layers.flatten()]
    print(f"Output layers: {output_layers}")
    
    return net, classes, output_layers

def detect_objects(img, net, outputLayers):
    height, width, channels = img.shape
    blob = cv2.dnn.blobFromImage(img, 0.00392, (416, 416), (0, 0, 0), True, crop=False)
    net.setInput(blob)
    outs = net.forward(outputLayers)
    class_ids = []
    confidences = []
    boxes = []
    for out in outs:
        for detection in out:
            scores = detection[5:]
            class_id = np.argmax(scores)
            confidence = scores[class_id]
            if confidence > 0.5:
                center_x = int(detection[0] * width)
                center_y = int(detection[1] * height)
                w = int(detection[2] * width)
                h = int(detection[3] * height)
                x = int(center_x - w / 2)
                y = int(center_y - h / 2)
                boxes.append([x, y, w, h])
                confidences.append(float(confidence))
                class_ids.append(class_id)
    indexes = cv2.dnn.NMSBoxes(boxes, confidences, 0.5, 0.4)
    return boxes, confidences, class_ids, indexes

def draw_labels(boxes, confidences, class_ids, indexes, classes, img):
    for i in range(len(boxes)):
        if i in indexes:
            x, y, w, h = boxes[i]
            label = str(classes[class_ids[i]])
            color = (0, 255, 0)
            cv2.rectangle(img, (x, y), (x + w, y + h), color, 2)
            cv2.putText(img, label, (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 1, color, 2)

def start_video():
    net, classes, output_layers = load_yolo()
    cap = cv2.VideoCapture(0)
    starting_time = time.time()
    frame_id = 0

    while True:
        ret, frame = cap.read()
        if not ret:
            print("Failed to grab frame")
            break
        frame_id += 1
        boxes, confidences, class_ids, indexes = detect_objects(frame, net, output_layers)
        draw_labels(boxes, confidences, class_ids, indexes, classes, frame)
        elapsed_time = time.time() - starting_time
        fps = frame_id / elapsed_time
        cv2.putText(frame, "FPS: " + str(round(fps, 2)), (10, 50), cv2.FONT_HERSHEY_SIMPLEX, 2, (0, 0, 0), 3)
        cv2.imshow("Image", frame)
        key = cv2.waitKey(1)
        if key == 27:  # ESC key to break
            break
    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    start_video()
